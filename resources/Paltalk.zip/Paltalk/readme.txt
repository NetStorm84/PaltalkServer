Your Installation is Complete!

Paltalk was installed in your windows start menu program
directory and a shortcut was created on your desktop.

Thank you for your interest and remember to send Paltalk to a
friend.  It's easy to do, just press the Invite button and
then supply their email address.

If you have any questions, you can get help by clicking on  
"Help" from the menu or by visiting our home site on the web, 
Paltalk.com and viewing our FAQ (frequently asked questions).

Also, feel free to email us at support@paltalk.com with your
comments and questions. 

!! NEW FEATURES in Verison 3.1 !!
---------------------------------

1. Voice Conferencing - Simply click "Groups" on the main
Paltalk screen to join existing conferences, create your
own or create a Permanent Group for you and your pals!

2. VIDEO, VIDEO, VIDEO!  Now you can actually see your pal
in addition to speaking with them.  Thats right, free video
conferencing!  Dont worry if you dont have a webcam, you can
still see your pal if they have one.  You can also get a 
webcam from Paltalk by clicking Help/Accessories.

3. Voice Mail - Simply double click an offline pal or right
click any pal or click "file", "voice mail" to launch the
voice mail window.  Then click "record" to record your voice
mail.  Once the mail has been recorded, click "send" to mail
the message.  Remember to type your pal's address in the "TO"
field so Paltalk knows where to send the voice mail.

4. Enhanced Privacy - Simply click Setup / Preferences from the 
main window and set new privacy settings.  You can now control 
whether other users see your email address, first and last names.

5. Enhanced Firewall Network Support - If you are having trouble
with the audio or video, click "Setup", "Advanced Sound Control"
and then check "Firewall/Home Network Voice Support".

Quick Tips to get started:
--------------------------

To Add Buddies to you list:
Click the "Add Pal" button, fill out any information you know.
You do not need to fill in all the fields.  You can just fill in
just the email or the first name and a couple of letters of their 
last anem and then hit the Search button.  A list of those people
matching the your search criteria will be displayed.  If your 
buddy is listed, click on them and then click the Add Pal button.

To Talk:
When you open the program, online users will appear in bold type.
To call a user, double click on their name.  Once they answer,
hold down the "ctrl" key on your keyboard to talk and release it
to listen.

To Hangup:
Click on the phone off the hook icon to hangup.  You can also double 
click on the buddy in the main list that you are talking to as 
an alternate way to hangup.

To Text Chat:
Single click to highlight a  user and then click on the Text/Video
button on the bottom left of the main wiindow.  This will bring up a 
communicator window to that person.  From that window simply type your
message and hit Enter.  If the user is not online when you send a 
text message, the message is stored and they will recevie it as soon
as they login the next time.

Communicator Window:
The text chat window described above can do much more than just text 
chat with a person so the window is more aptly descibed as a 
communication window.  From the communicator window you can text chat,
audio call, video call and send files.

To Video:
Bring up a communicator window with the person you wish to exchange
video with.  You do this by selecting an online buddy from the main 
window and pressing the Text/Video button.  Then press the Video button.
Your buddy will be asked if they agree to turn on video and if they do
the screen will enlarge and you will see two images on the right.  One
of you and one of them.  The image of you should show fluid movement.  
The image of your buddy will update in snap shots, one every couple 
of seconds.

Right Click Menu:
All functions are also accessible with a right click menu which 
may be seen by right clicking on a user (whether online or
offline).

Help Screen:
There is extensive help which may be accessed by clicking the
Help menu on the top right of the PalList.

Ctrl-key Talk Mode:
Now you can easily use the CTRL key on your keyboard to talk and
listen with paltalk.  First, make sure Hands Free mode is NOT
checked under Options on the main widnow. Then, when you're 
in an audio call with someone, just press and hold the CTRL key 
to talk and release it to listen.

Hands Free Mode:
This feature may be selected by uners Options off the main window.
This feature will allow you to talk hands free without having to 
hold down the CRL key to talk.  For this feature to work correctly 
you must adjust a threshold meter.  Please see the Hands Free 
section explained in the help to explain fully how to do this.

Send Paltalk to a friend:
If you'd like to talk to a frined using Paltalk who's not currently
a Paltalk member you can easily invite them to join by clicking 
"Invite" on the front panel of your PalList.  A dialog box will 
then be displayed for you to input your pals email address or to 
search for the address in your address book if you choose.

File Transfer:  
You can send a file to an online pal by right-clicking their name
and selecting 'File Transfer'.  Then pick a file from your desktop
machine and send it along!  

Privacy:
This feature allows you to restrict people from contacting you
unless they are on your PalList.  Simply click Setup / Privacy 
Blocking to invoke this feature.


Enjoy Paltalking!


Team Paltalk
